<html>

<head>

<title>Success</title>

<style>

body{
font-family:Arial,sans-serif;
background:#eef3f8;
}

.box{
width:500px;
margin:120px auto;
background:white;
padding:35px;
text-align:center;
border-radius:15px;
box-shadow:0px 0px 15px rgba(0,0,0,0.15);
}

.success{
font-size:60px;
}

h2{
color:#27ae60;
}

p{
color:#555;
}

.btn{
display:inline-block;
margin-top:15px;
padding:12px 25px;
background:#3498db;
color:white;
text-decoration:none;
border-radius:8px;
}

.btn:hover{
background:#2980b9;
}

</style>

</head>

<body>

<div class="box">

<div class="success">
?
</div>

<h2>Application Saved Successfully</h2>

<p>
Your job application has been saved successfully! You can now add another application or view all submissions.
</p>

<a class="btn" href="index.jsp">
Add Another Application
</a>

</div>

</body>

</html>