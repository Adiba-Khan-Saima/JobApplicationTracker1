<%@ page import="java.sql.*" %>

<%
Class.forName("com.mysql.cj.jdbc.Driver");

Connection con=DriverManager.getConnection(
"jdbc:mysql://localhost:3306/jobdb",
"root",
""
);

Statement st=con.createStatement();

ResultSet totalRs=st.executeQuery("SELECT COUNT(*) FROM jobs");
totalRs.next();
int total=totalRs.getInt(1);

ResultSet appliedRs=st.executeQuery("SELECT COUNT(*) FROM jobs WHERE status='Applied'");
appliedRs.next();
int applied=appliedRs.getInt(1);

ResultSet interviewRs=st.executeQuery("SELECT COUNT(*) FROM jobs WHERE status='Interview'");
interviewRs.next();
int interview=interviewRs.getInt(1);

ResultSet selectedRs=st.executeQuery("SELECT COUNT(*) FROM jobs WHERE status='Selected'");
selectedRs.next();
int selected=selectedRs.getInt(1);

ResultSet rejectedRs=st.executeQuery("SELECT COUNT(*) FROM jobs WHERE status='Rejected'");
rejectedRs.next();
int rejected=rejectedRs.getInt(1);

String search=request.getParameter("search");
String filter=request.getParameter("filter");

if(search==null){
search="";
}

if(filter==null){
filter="All";
}

String sql="SELECT * FROM jobs WHERE 1=1";

if(!search.equals("")){
sql=sql+" AND (company LIKE ? OR position LIKE ?)";
}

if(!filter.equals("All")){
sql=sql+" AND status=?";
}

sql=sql+" ORDER BY id ASC";

PreparedStatement ps=con.prepareStatement(sql);

int index=1;

if(!search.equals("")){
ps.setString(index++,"%"+search+"%");
ps.setString(index++,"%"+search+"%");
}

if(!filter.equals("All")){
ps.setString(index++,filter);
}

ResultSet rs=ps.executeQuery();
%>

<html>
<head>
<title>Smart Job Application Tracker</title>

<style>
body{
font-family:Arial,sans-serif;
background:#eef3f8;
margin:0;
padding:20px;
}

h1{
text-align:center;
color:#2c3e50;
}

.dashboard{
display:flex;
justify-content:center;
gap:15px;
flex-wrap:wrap;
margin-bottom:25px;
}

.card{
width:160px;
padding:15px;
border-radius:12px;
color:white;
text-align:center;
font-weight:bold;
box-shadow:0 3px 10px rgba(0,0,0,0.2);
}

.total{ background:#34495e; }
.applied{ background:#3498db; }
.interview{ background:#f39c12; }
.selected{ background:#27ae60; }
.rejected{ background:#e74c3c; }

.search-box{
width:95%;
margin:0 auto 20px auto;
background:white;
padding:18px;
border-radius:10px;
box-shadow:0 0 10px rgba(0,0,0,0.12);
text-align:center;
}

.search-box input,
.search-box select{
padding:10px;
width:220px;
border:1px solid #ccc;
border-radius:6px;
margin:5px;
}

.search-box button{
padding:10px 18px;
background:#3498db;
color:white;
border:none;
border-radius:6px;
cursor:pointer;
}

.search-box button:hover{
background:#2980b9;
}

.clear{
padding:10px 18px;
background:#7f8c8d;
color:white;
text-decoration:none;
border-radius:6px;
}

table{
width:95%;
margin:auto;
border-collapse:collapse;
background:white;
box-shadow:0 0 12px rgba(0,0,0,0.15);
}

th{
background:#2c3e50;
color:white;
padding:12px;
}

td{
padding:10px;
text-align:center;
border:1px solid #ddd;
}

tr:nth-child(even){
background:#f8f9fa;
}

.status-applied{
color:#3498db;
font-weight:bold;
}

.status-interview{
color:#f39c12;
font-weight:bold;
}

.status-selected{
color:#27ae60;
font-weight:bold;
}

.status-rejected{
color:#e74c3c;
font-weight:bold;
}

.delete{
background:#e74c3c;
color:white;
padding:7px 12px;
border-radius:5px;
text-decoration:none;
font-weight:bold;
}

.delete:hover{
background:#c0392b;
}

.back{
text-align:center;
margin-top:25px;
}

.back a{
background:#3498db;
color:white;
padding:10px 20px;
border-radius:6px;
text-decoration:none;
}

.footer{
margin-top:30px;
text-align:center;
color:#555;
}
</style>
</head>

<body>

<h1>Smart Job Application Tracker</h1>

<div class="dashboard">

<div class="card total">
Total<br><br>
<%=total%>
</div>

<div class="card applied">
Applied<br><br>
<%=applied%>
</div>

<div class="card interview">
Interview<br><br>
<%=interview%>
</div>

<div class="card selected">
Selected<br><br>
<%=selected%>
</div>

<div class="card rejected">
Rejected<br><br>
<%=rejected%>
</div>

</div>

<div class="search-box">
<form action="view.jsp" method="get">

<input type="text" name="search" placeholder="Search company or position" value="<%=search%>">

<select name="filter">
<option value="All" <% if(filter.equals("All")) out.print("selected"); %>>All Status</option>
<option value="Applied" <% if(filter.equals("Applied")) out.print("selected"); %>>Applied</option>
<option value="Interview" <% if(filter.equals("Interview")) out.print("selected"); %>>Interview</option>
<option value="Selected" <% if(filter.equals("Selected")) out.print("selected"); %>>Selected</option>
<option value="Rejected" <% if(filter.equals("Rejected")) out.print("selected"); %>>Rejected</option>
</select>

<button type="submit">Search</button>

<a class="clear" href="view.jsp">Clear</a>

</form>
</div>

<table>
<tr>
<th>ID</th>
<th>Company</th>
<th>Position</th>
<th>Apply Date</th>
<th>Status</th>
<th>Action</th>
</tr>

<%
int serial=1;

while(rs.next()){

String status=rs.getString("status");
String cssClass="";

if(status.equals("Applied"))
cssClass="status-applied";
else if(status.equals("Interview"))
cssClass="status-interview";
else if(status.equals("Selected"))
cssClass="status-selected";
else if(status.equals("Rejected"))
cssClass="status-rejected";
%>

<tr>
<td><%=serial++%></td>
<td><%=rs.getString("company")%></td>
<td><%=rs.getString("position")%></td>
<td><%=rs.getString("apply_date")%></td>

<td class="<%=cssClass%>">
<%=status%>
</td>

<td>
<a class="delete" href="delete.jsp?id=<%=rs.getInt("id")%>"
onclick="return confirm('Are you sure you want to delete this application?');">
Delete
</a>
</td>
</tr>

<%
}

con.close();
%>

</table>

<div class="back">
<a href="index.jsp">Back To Home</a>
</div>

<div class="footer">
Keep growing, keep applying. Every step counts!
</div>

</body>
</html>