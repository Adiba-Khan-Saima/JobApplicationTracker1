<%@ page import="java.sql.*" %>

<%

String company=request.getParameter("company");

String position=request.getParameter("position");

String date=request.getParameter("date");

String status=request.getParameter("status");

Class.forName("com.mysql.cj.jdbc.Driver");

Connection con=DriverManager.getConnection(
"jdbc:mysql://localhost:3306/jobdb",
"root",
""
);

PreparedStatement ps=con.prepareStatement(
"insert into jobs(company,position,apply_date,status) values(?,?,?,?)"
);

ps.setString(1,company);

ps.setString(2,position);

ps.setString(3,date);

ps.setString(4,status);

ps.executeUpdate();

response.sendRedirect("success.jsp");

%>