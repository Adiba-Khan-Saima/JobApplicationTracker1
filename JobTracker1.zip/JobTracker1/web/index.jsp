<html>

<head>

<title>Smart Job Application Tracker</title>

<style>

body{
font-family:Arial,sans-serif;
background:#eef3f8;
}

.container{
width:550px;
margin:50px auto;
background:white;
padding:30px;
border-radius:15px;
box-shadow:0px 0px 15px rgba(0,0,0,0.15);
}

h2{
text-align:center;
color:#2c3e50;
margin-bottom:5px;
}

.subtitle{
text-align:center;
color:gray;
margin-bottom:25px;
}

label{
font-weight:bold;
color:#2c3e50;
}

input,select{
width:100%;
padding:12px;
margin-top:6px;
margin-bottom:15px;
border:1px solid #ccc;
border-radius:8px;
box-sizing:border-box;
}

button{
background:#3498db;
color:white;
border:none;
padding:12px;
width:100%;
cursor:pointer;
font-size:16px;
border-radius:8px;
}

button:hover{
background:#2980b9;
}

.link{
text-align:center;
margin-top:20px;
}

.link a{
text-decoration:none;
color:#3498db;
font-weight:bold;
}

.footer{
margin-top:25px;
text-align:center;
color:#777;
font-size:14px;
}

</style>

</head>

<body>

<div class="container">

<h2>Smart Job Application Tracker</h2>

<p class="subtitle">
Track and manage your career applications efficiently
</p>

<form action="save.jsp" method="post">

<label>Company Name</label>
<input type="text" name="company" required>

<label>Position</label>
<input type="text" name="position" required>

<label>Apply Date</label>
<input type="date" name="date" required>

<label>Status</label>

<select name="status">

<option>Applied</option>
<option>Interview</option>
<option>Rejected</option>
<option>Selected</option>

</select>

<button type="submit">
Save Application
</button>

</form>

<div class="link">

<a href="view.jsp">
View Applications
</a>

</div>

<div class="footer">

Developed By: Adiba Khan Saima

</div>

</div>

</body>

</html>